plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tiko.customwallpaper"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.tiko.customwallpaper"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}


dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
}
